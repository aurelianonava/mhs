## mhs
Canvas will be divided into sections 200 x 200 and each student will push an object, such as an ellipse, to this designated area. This 200 x 200 are can not overlap with that of another student. 

I will take up the first of these rectagles in the area encompassed by (200, 200).
#### To change the background color your space, change the fill above your rect. I have marked each rect whith each persons name so far. -Jose Angel Orozco

### Student Sections:

**Mr. Nava:**

.....I'll insert my explation for my object in my 200 x 200 rectagle....

Check out my Gist for this project: [Mr. Nav's Gist](https://gist.github.com/aurelianonava/23b14a98f340ab4a8408b6247e5226e3 "Mr. Nava's Gist")


**John Gonazalez:**

This is where you'll insert your explation for your object in your rectagle....


**Jose Orozco:**



**Michael Esparza:**



**Angel Gomez:**



**Juan Guzman:**



**Daniel Ayala:**



**Monica Jaimes:**